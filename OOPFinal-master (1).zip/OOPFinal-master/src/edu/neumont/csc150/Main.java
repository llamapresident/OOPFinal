package edu.neumont.csc150;

import edu.neumont.csc150.potions.maker.PotionMaker;

public class Main {
    public static void main(String[] args) {
        new PotionMaker().run();

    }
}