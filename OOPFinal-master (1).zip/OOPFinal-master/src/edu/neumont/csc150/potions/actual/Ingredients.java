/**
 * @author zdyse
 * @createdOn 3/2/2023 at 1:52 PM
 * @projectName OOPFinal
 * @packageName edu.neumont.csc150.potions.maker;
 */
package edu.neumont.csc150.potions.actual;

public enum Ingredients {
    lizards_tail, spider_glands, chicken_blood, bear_fat, rum, sugar
}