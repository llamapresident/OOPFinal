package edu.neumont.csc150.potions.actual;

public abstract class potion2 extends potion{
    Ingredients ingredient2;
    public abstract void Ingredient2(String ingredients);
    public abstract void setEffect();
}
