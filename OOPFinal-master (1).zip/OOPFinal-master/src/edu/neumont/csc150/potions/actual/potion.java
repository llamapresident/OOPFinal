package edu.neumont.csc150.potions.actual;

public abstract class potion {
    String effect;
    Ingredients ingredient;
    public abstract void Ingredient(String ingredients);
    public abstract void setEffect();
}
